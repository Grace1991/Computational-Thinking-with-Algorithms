import java.text.DecimalFormat;


public class Main {
	public static DecimalFormat df = new DecimalFormat("#.###");//this is a formatter used for formatting 
	
	public static void mainPrintHeader()//method for printing the information about the sizes of the array
	{
		int size= 100;
		System.out.print("Size\t\t");
		for (int i = 1; i <=15 ; i++) 
		{
			
			System.out.print(size + "\t"); //printing size of the array for user display
			if(i==1) 
				size+=150;
			else if(i>1&&i<=5)	
				size+=250;
			else
				size+=1250;
		}
		
	}
	public static void mainSelSort()//this is the method which implements the selection sort algorithm
	{
		int size= 100;
		System.out.print("\nSelection Sort\t");
		double res= 0.01 ;
		int[] arr;
		for (int i = 1; i <=15 ; i++) //for loop used for each of the different size of arrays
		{
			res = 0;
			for (int j = 0; j < 10; j++) //the loop iterates 10 time for the bench marking 
			{
				arr = Tester.randomArray(size);//here we have used the random array method for the random number filled with array
				long startTime = System.nanoTime() ;
				Tester.selectionSort(arr);//Using the selection sort algorithm which is static in Tester class
				long endTime = System.nanoTime() ;
				long timeElapsed = endTime - startTime ;
				double elapsedMillis = timeElapsed /1000000;
				
				res+= elapsedMillis;
				
				
			}
			
			double ave_res =  res/10;
			
			System.out.printf("%.3f\t",ave_res);
			if(i==1)
				size+=150;
			else if(i>1&&i<=5)
				size+=250;
			else
				size+=1250;
		}
		
	}
	public static void mainHeapSort()
	{
		int size= 100;
		System.out.print("\nHeap Sort\t");
		double res= 0.01 ;
		int[] arr;
		for (int i = 1; i <=15 ; i++) //for loop used for each of the different size of arrays
		{
			res = 0;
			for (int j = 0; j < 10; j++) //the loop iterates 10 time for the bench marking 
			{
				arr = Tester.randomArray(size);
				long startTime = System.nanoTime() ;
				Tester.heapSort(arr, size);//same as above here we have used the heap sort algorithm
				long endTime = System.nanoTime() ;
				long timeElapsed = endTime - startTime ;
				double elapsedMillis = timeElapsed /1000000;
				
				res+= elapsedMillis;
				
			}
			
			double ave_res =  res/10;
		
			System.out.printf("%.3f\t",ave_res);
			if(i==1)
				size+=150;
			else if(i>1&&i<=5)
				size+=250;
			else
				size+=1250;
		}
		
		
	}
	public static void mainCountSort()
	{
		int size= 100;
		System.out.print("\nCount Sort\t");
		double res= 0.01 ;
		int[] arr;
		for (int i = 1; i <=15 ; i++) //for loop used for each of the different size of arrays
		{
			res = 0;
			for (int j = 0; j < 10; j++) //the loop iterates 10 time for the bench marking 
			{
				arr = Tester.randomArray(size);
				long startTime = System.nanoTime() ;
				Tester.countSort(arr, size);//count sort algorithm 
				long endTime = System.nanoTime() ;
				long timeElapsed = endTime - startTime ;
				double elapsedMillis = timeElapsed /1000000;
				
				res+= elapsedMillis;
				
			}
			
			double ave_res =  res/10;

			System.out.printf("%.3f\t",ave_res);
			if(i==1)
				size+=150;
			else if(i>1&&i<=5)
				size+=250;
			else
				size+=1250;
		}
		
		
	}
	public static void mainBucSort()
	{
		int size= 100;
		System.out.print("\nBucket Sort\t");//for loop used for each of the different size of arrays
		double res= 0.01 ;
		int[] arr;
		for (int i = 1; i <=15 ; i++) //for loop used for each of the different size of arrays
		{
			res = 0;
			for (int j = 0; j < 10; j++) //the loop iterates 10 time for the bench marking 
			{
				arr = Tester.randomArray(size);
				long startTime = System.nanoTime() ;
				Tester.bucket(arr);
				long endTime = System.nanoTime() ;
				long timeElapsed = endTime - startTime ;
				double elapsedMillis = timeElapsed /1000000;
				
				res+= elapsedMillis;
				
			}
			
			double ave_res =  res/10;

			System.out.printf("%.3f\t",ave_res);
			if(i==1)
				size+=150;
			else if(i>1&&i<=5)
				size+=250;
			else
				size+=1250;
		}
		
		
	}
	public static void mainShellSort()
	{
		int size= 100;
		System.out.print("\nShell Sort\t");
		double res= 0.01 ;
		int[] arr;
		for (int i = 1; i <=15 ; i++) //for loop used for each of the different size of arrays
		{
			res = 0;
			for (int j = 0; j < 10; j++) //the loop iterates 10 time for the bench marking 
			{
				arr = Tester.randomArray(size);
				long startTime = System.nanoTime() ;
				Tester.shell(arr, size);
				long endTime = System.nanoTime() ;
				long timeElapsed = endTime - startTime ;
				double elapsedMillis = timeElapsed /1000000;
				
				res+= elapsedMillis;
				
			}
			
			double ave_res =  res/10;

			System.out.printf("%.3f\t",ave_res);
			if(i==1)
				size+=150;
			else if(i>1&&i<=5)
				size+=250;
			else
				size+=1250;
		}
		
		
	}
	public static void main(String[] args) 
	{
		mainPrintHeader();
		mainSelSort();	
		mainHeapSort();	
		mainCountSort();
		mainBucSort();
		mainShellSort();
		
	}

}
