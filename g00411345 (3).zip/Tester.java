
public class Tester {

	static int [] randomArray ( int n)
	{
		int [] array = new int [n];
		for( int i = 0; i < n ; i ++)
		{
			array [i] = (int)( Math . random () * 100) ;
		}
		return array ;
	}
	
	  public static void selectionSort(int[] arr)
	  {  
	        for (int i = 0; i < arr.length - 1; i++)  
	        {  
	            int index = i;  
	            for (int j = i + 1; j < arr.length; j++){  
	                if (arr[j] < arr[index]){  
	                    index = j;//searching for lowest index  
	                }  
	            }  
	            int smallerNumber = arr[index];   
	            arr[index] = arr[i];  
	            arr[i] = smallerNumber;  
	        }  
	   }
	  
	  static void heapify(int a[], int n, int i)  
	  {  
	      int largest = i; // Initialize largest as root  
	      int left = 2 * i + 1; // left child  
	      int right = 2 * i + 2; // right child  
	      // If left child is larger than root  
	      if (left < n && a[left] > a[largest])  
	          largest = left;  
	      // If right child is larger than root  
	      if (right < n && a[right] > a[largest])  
	          largest = right;  
	      // If root is not largest  
	      if (largest != i) {  
	          // swap a[i] with a[largest]  
	          int temp = a[i];  
	          a[i] = a[largest];  
	          a[largest] = temp;  
	            
	          heapify(a, n, largest);  
	      }  
	  } 
	  
	  /*Function to implement the heap sort*/  
	  static void heapSort(int a[], int n)  
	  {  
	      for (int i = n / 2 - 1; i >= 0; i--) 
	      {
	    	  heapify(a, n, i);  
	      }  
	    
	      // One by one extract an element from heap  
	      for (int i = n - 1; i >= 0; i--) 
	      {  
	          /* Move current root element to end*/  
	          // swap a[0] with a[i]  
	          int temp = a[0];  
	          a[0] = a[i];  
	          a[i] = temp;  
	            
	          heapify(a, i, 0);  
	      }  
	  }  
	  
	  //getMax function for the count sort method 
	  static int getMax(int[] a, int n)
	  {  
		  int max = a[0];  
		  for(int i = 1; i<n; i++) {  
		      if(a[i] > max)  
		         max = a[i];  
		  }  
		  return max; //maximum element from the array  
	   }  
		  
	  static void countSort(int[] a, int n) // function to perform counting sort  
		{  
		   int[] output = new int [n+1];  
		   int max = getMax(a, n);  
		   //int max = 42;  
		   int[] count = new int [max+1]; //create count array with size [max+1]  
		  
		  for (int i = 0; i <= max; ++i)   
		  {  
		    count[i] = 0; // Initialize count array with all zeros  
		  }  
		    
		  for (int i = 0; i < n; i++) // Store the count of each element  
		  {  
		    count[a[i]]++;  
		  }  
		  
		  for(int i = 1; i<=max; i++) 
		  {
			 count[i] += count[i-1]; //find cumulative frequency
		  }
		      
		  /* This loop will find the index of each element of the original array in count array, and 
		     place the elements in output array*/  
		  for (int i = n - 1; i >= 0; i--) 
		  {  
		    output[count[a[i]] - 1] = a[i];  
		    count[a[i]]--; // decrease count for same numbers  
		  }  
		  
		  for(int i = 0; i<n; i++) 
		  {  
		      a[i] = output[i]; //store the sorted elements into main array  
		  }  
		  
		} 
		
		
		static int getMax(int a[]) // function to get maximum element from the given    
		{  
		    int n = a.length;  
		    int max = a[0];  
		    for (int i = 1; i < n; i++)  
		    if (a[i] > max)  
		    max = a[i];  
		    return max;  
		}  
		
		static void bucket(int a[]) // function to implement bucket sort  
		{  
		    int n = a.length;  
		    int max = getMax(a); //max is the maximum element of array  
		    int bucket[] = new int[max+1];   
		    for (int i = 0; i <= max; i++)  
		    {  
		        bucket[i] = 0;  
		    }  
		    for (int i = 0; i < n; i++)  
		    {  
		        bucket[a[i]]++;  
		          
		    }  
		    for (int i = 0, j = 0; i <= max; i++)  
		    {  
		        while (bucket[i] > 0)  
		        {  
		            a[j++] = i;  
		            bucket[i]--;  
		        }  
		    }  
		}  
		/* function to implement shellSort */  
		static void shell(int a[], int n)  
		{  
		    /* Rearrange the array elements at n/2, n/4, ..., 1 intervals */  
		    for (int interval = n/2; interval > 0; interval /= 2)  
		    {  
		        for (int i = interval; i < n; i += 1)  
		        {  
		            /* store a[i] to the variable temp and make the ith position empty */  
		            int temp = a[i];  
		            int j;        
		            for (j = i; j >= interval && a[j - interval] > temp; j -= interval)  
		            {
		            	a[j] = a[j - interval];
		            }
		            
		            /* put temp (the original a[i]) in its correct position */  
		            a[j] = temp;  
		        }  
		    }  
		}  
	
}
